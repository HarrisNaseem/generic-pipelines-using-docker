package com.example.hello;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;
import java.util.Scanner;

@Controller
@EnableAutoConfiguration
@SpringBootApplication
public class HelloApplication {

	@RequestMapping("/")
	@ResponseBody
	String home() {
		return "Hello World!";
	}

	public static void main(String[] args) {
		SpringApplication.run(HelloApplication.class, args);
		
		System.out.println(" Welcome to Java Calculator v0.1 \n");
        Scanner scanner = new Scanner(System.in);

        System.out.println("\n Please enter two numbers");
        System.out.print("\n First number: ");
        int firstNumber = scanner.nextInt();
        System.out.print("\n Second number: ");
        int secondNumber = scanner.nextInt();
        System.out.println("\n Select between (*,/,+,-)\n Type out the character in a single letter: ");
        String operation = scanner.next();

        String eo = "You have selected ";

        switch (operation) {
        case "*": 
            System.out.println(eo + "* \n Your Result: "+ ( firstNumber * secondNumber )); 
            break;
        case "/": 
            System.out.println(eo + "/ \n Your Result: "+ ( firstNumber / secondNumber )); 
            break;
        case "+": 
            System.out.println(eo + "+ \n Your Result: "+ ( firstNumber + secondNumber ));
            break;
        case "-": 
            System.out.println(eo + "- \n Your Result: "+ ( firstNumber - secondNumber )); 
            break;
        default: System.out.println("\n Please select a valid character"); 
        }

        scanner.close();
        System.out.println(" Closing Application ");
	}
}
